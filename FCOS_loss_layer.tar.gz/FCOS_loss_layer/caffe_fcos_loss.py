import os
import sys
import torch
from torch import nn
from torch import tensor
sys.path.insert(0, "/home/dm/projects/caffe-ssd/python")
import caffe
import numpy as np

from defaults import _C as cfg
from loss import make_fcos_loss_evaluator
from bounding_box import BoxList



class FCOS_Loss(caffe.Layer):
    def setup(self, bottom, top):
        self.device = torch.device('cuda:0')
        self.cfg = cfg
        self.loss_eval = make_fcos_loss_evaluator(self.cfg)
        self.num_classes = self.cfg.MODEL.FCOS.NUM_CLASSES
        img_w, img_h = self.cfg.MODEL.FCOS.IMG_SIZE
        # h, w
        self.fpn_strides = cfg.MODEL.FCOS.FPN_STRIDES
        feature_sizes = [[img_h/s, img_w/s] for s in self.fpn_strides]
        self.locations = self.compute_locations(feature_sizes)
        self.location_num = sum([l.size()[0] for l in self.locations])

        # pytorch-caffe data interface
        self.cls = torch.zeros([0], requires_grad=True, device=self.device)
        self.reg = torch.zeros([0], requires_grad=True, device=self.device)
        self.centerness = torch.zeros([0], requires_grad=True, device=self.device)
        self.loss = None


    def forward(self, bottom, top):
        '''
        bottom [0]: cls_flatten [N*num_location*num_classes]
        bottom [1]: reg_box_flattene [N*num_location*4]
        bottom [2]: centerness_flatten [N*num_location]
        bottom [3]: targets
        '''
        self.cls = tensor(bottom[0].data, requires_grad=True, device=self.device)
        self.reg = tensor(bottom[1].data, requires_grad=True, device=self.device)
        self.centerness = tensor(bottom[2].data, requires_grad=True, device=self.device)

        # convert target to list of bboxlist
        # TODO
        empty_target = BoxList(tensor([[1, 2, 50, 50]], device=self.device), [640, 320], mode="xywh").convert("xyxy")
        empty_target.add_field("labels", torch.tensor([1], device=self.device))

        t_list = self.blob_to_bbox(bottom[3])

        # call the pytorch forward
        self.loss = self.loss_eval(self.locations, self.cls.reshape(-1, self.num_classes),
                             self.reg.reshape(-1, 4),
                             self.centerness, t_list)

        top[0].data[:] = sum([x.cpu().item() for x in self.loss])

    def reshape(self, bottom, top):
        top[0].reshape(1, 1)

    def backward(self, top, propagate_down, bottom):
        # call pytorch backward
        for l in self.loss:
            l.backward()

        bottom[0].diff[:] = self.cls.grad.cpu().numpy()
        bottom[1].diff[:] = self.reg.grad.cpu().numpy()
        bottom[2].diff[:] = self.centerness.grad.cpu().numpy()
        # put gradients to right places



    def compute_locations(self, feature_sizes):
        locations = []
        for level, f_size in enumerate(feature_sizes):
            h, w = f_size
            locations_per_level = self.compute_locations_per_level(
                h, w, self.fpn_strides[level],
                self.device
            )
            locations.append(locations_per_level)
        return locations

    def compute_locations_per_level(self, h, w, stride, device):
        shifts_x = torch.arange(
            0, w * stride, step=stride,
            dtype=torch.float32, device=device
        )
        shifts_y = torch.arange(
            0, h * stride, step=stride,
            dtype=torch.float32, device=device
        )
        shift_y, shift_x = torch.meshgrid(shifts_y, shifts_x)
        shift_x = shift_x.reshape(-1)
        shift_y = shift_y.reshape(-1)
        locations = torch.stack((shift_x, shift_y), dim=1) + stride // 2
        return locations

    def blob_to_bbox(self, blob):
        """

        :param blob: N*1*num_gt*8
                blob[:,:,:, 1] label
                blob[:,:,:, 3:7] x_min,y_min,x_max,y_max
        :return:
        """
        data = blob.data
        N = data.shape[0]
        t_list = []
        for i in range(N):
            boxes = data[i, 0, :, 3:7]
            boxes = torch.as_tensor(boxes, device=self.device).reshape(-1, 4)  # guard against no boxes
            # assume the coordinates are normalized to 1
            target = BoxList(boxes, [1, 1], mode="xyxy")

            classes = torch.tensor(data[i, 0, :, 1], device=self.device)
            target.add_field("labels", classes)
            t_list.append(target)
        return t_list





if __name__ == '__main__':
    caffe.set_mode_gpu()
    net = caffe.Net("test.prototxt", caffe.TRAIN)

    t_blob = np.asarray([[0, 1, 0, 0.2, 0.2, 0.5, 0.5, 0],
                         [1, 2, 0, 0.2, 0.2, 0.5, 0.5, 0]], dtype=np.float32)

    t_blob = np.asarray([t_blob, t_blob])
    t_blob = t_blob.reshape([2, 1, 2, 8])

    net.blobs['target'].data[:] = t_blob
    ret = net.forward()
    print(ret)
    net.layers[-1].backward(ret, [True, True, True, False], [net.blobs['cls'], net.blobs['reg'], net.blobs['centerness']])
    '''
    f1 = torch.zeros(1, 1, 320, 640, device=torch.device('cuda:0'))
    f2 = torch.zeros(1, 1, 160, 320)
    features = [f1, f2]
    ret = compute_locations(features, [2, 4])
    print(ret)
    '''
    #for i in range(100):
    #    print(i)
    #    net.forward()
    #    net.layers[-1].backward(1,1,1)
